import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:jadurjini_user/models/product_model.dart';
import 'package:jadurjini_user/provider/product_provider.dart';

class HomePage extends StatefulWidget {
  static const String routeName='/homepage';
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List <Product> products = [];
  ProductProvider repository = ProductProvider();

  @override
  void initState() {
    getAllProducts();
    print(products.length);
    super.initState();
  }

  getAllProducts()async{
    products = await repository.getAllProducts();
    print(products.length);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: PopupMenuButton(
            icon: Icon(Icons.menu,size: 30,),
            itemBuilder: (context){
              return [
                PopupMenuItem<int>(
                  value: 0,
                  child: Text("Profile"),
                ),

                PopupMenuItem<int>(
                  value: 1,
                  child: Text("Settings"),
                ),

                PopupMenuItem<int>(
                  value: 2,
                  child: Text("Login"),
                ),
              ];
            },
            onSelected:(value){
              if(value == 0){
                print("Profile menu is selected.");
              }else if(value == 1){
                print("Settings menu is selected.");
              }else if(value == 2){
                print("LogIn menu is selected.");
              }
            }
        ),
        title: Row(
          children: const [
            Icon(Icons.location_on,size: 20,),
            Text(
              'New Market, Rajshahi',
              style: TextStyle(fontSize: 17),
            ),
          ],
        ),
        actions: const [
          Icon(Icons.shopping_cart),
        ],
      ),
      body: ListView.builder(
          itemCount: products.length,
          itemBuilder: (context, index){
            final product = products[index];
            return ListTile(
              title: Text(product.productName),
            );
          }
      )
    );
  }

}
