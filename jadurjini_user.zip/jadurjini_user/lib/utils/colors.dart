import 'package:flutter/material.dart';

const Color themeColorBlue = Color(0xFF565D91);
const Color firstbuttoncolor = Color(0xFFF1BE6C);
const Color backgroundwhite= Color(0xFFF5F5F2);
const Color acceptbutcol= Color(0xFF01B075);
const Color declinebutcol= Color(0xFFFD476D);