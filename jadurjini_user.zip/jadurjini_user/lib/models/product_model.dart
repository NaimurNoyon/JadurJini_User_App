class Product{
  final String sId;
  final String productCategory;
  final String productSubCategory;
  final String productName;
  final int productPrice;
  final String productImage;
  final String productRating;
  final String productDescription;
  final String productType;
  final String productSize;
  final String productColor;
  final String shopLocation;
  final String shopName;
  final String shopImage;
  final String shopRating;

  Product({
    required this.sId,
    required this.productCategory,
    required this.productSubCategory,
    required this.productName,
    required this.productPrice,
    required this.productImage,
    required this.productRating,
    required this.productDescription,
    required this.productType,
    required this.productSize,
    required this.productColor,
    required this.shopLocation,
    required this.shopName,
    required this.shopImage,
    required this.shopRating
});


  factory Product.fromJson(Map<String, dynamic> e){
    return Product(
        sId: e['_id'],
        productCategory: e['productCategory'],
        productSubCategory: e['productSubCategory'],
        productName: e['productName'],
        productPrice: e['productPrice'],
        productImage: e['productImage'],
        productRating: e['productRating'],
        productDescription: e['productDescription'],
        productType: e['productType'],
        productSize: e['productSize'],
        productColor: e['productColor'],
        shopLocation: e['shopLocation'],
        shopName: e['shopName'],
        shopImage: e['shopImage'],
        shopRating: e['shopRating']
    );
  }
}