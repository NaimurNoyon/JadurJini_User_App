import 'package:flutter/material.dart';
import 'package:jadurjini_user/pages/activity_page.dart';
import 'package:jadurjini_user/pages/first_page.dart';
import 'package:jadurjini_user/pages/home_page.dart';
import 'package:jadurjini_user/pages/profile_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
      ),
      initialRoute: FirstPage.routeName,
      routes: {
        FirstPage.routeName: (context)=>FirstPage(),
        HomePage.routeName: (context)=>HomePage(),
        ActivityPage.routeName: (context)=>ActivityPage(),
        ProfilePage.routeName: (context)=>ProfilePage()
      },
    );
  }
}
