import 'dart:convert';
import 'package:jadurjini_user/models/product_model.dart';
import 'package:http/http.dart' as http;

class ProductProvider{
/*  static Future<List<Product>> getAllProducts() async {
    print('getAllProducts called');
    const url = 'https://jadurjini.vercel.app/testProducts';
    final uri = Uri.parse(url);
    final response = await http.get(uri);
    final body = response.body;
    final json = jsonDecode(body);
    final results = json['results'] as List<dynamic>;
    final products = results.map((e) {
        return Product.fromMap(e);
    }).toList();
    return products;
  }*/
  String uri = "https://jadurjini.vercel.app/testProducts";
  Future getAllProducts() async {
    try {
      final response = await http.get(Uri.parse(uri));
      print(response.statusCode);
      if (response.statusCode == 200) {
        Iterable it = jsonDecode(response.body)[0];
        List<Product> productList = it.map((e) => Product.fromJson(e)).toList();
        return productList;
      } else {
        throw Exception('Failed to load data');
      }
    } catch (e) {
      return e.toString();
    }
  }

}